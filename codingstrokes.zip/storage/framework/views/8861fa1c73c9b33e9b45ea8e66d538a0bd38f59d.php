<?php $__env->startSection('title'); ?>
    Dashboard - <?php echo e(Auth::user()->name); ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                <?php endif; ?>
            <h3>We are currently in development phase. Please give us some time. Till then enjoy the articles below</h3><br>
            <h5>Latest Articles :</h5> <br><br>
            
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href='<?php echo $article->urldest; ?>' ><h4><?php echo $article->title; ?></h4></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>