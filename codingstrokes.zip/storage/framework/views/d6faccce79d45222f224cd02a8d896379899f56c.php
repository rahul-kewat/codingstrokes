<?php $__env->startSection('title'); ?>
    Search  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
                <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                <?php endif; ?>
        <?php if(count($articles)>0): ?>
            <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
            <div class="media bg-light position-relative " style="border-radius:1%; padding:2%">
                <div class="media-body">
                    <div class="row">
                        <div class="col-sm-2" style="word-wrap:break-word";>
                            <img src="<?php echo asset('images/codingstrokes/tags'); ?>/<?php echo $article->tagDetails->tag_image; ?>" height="20px" class="mr-3" alt="<?php echo $article->tagDetails->tag_name; ?>">
                            <br>
                            <b><?php echo $article->tagDetails->tag_name; ?></b>
                        </div>
                        <div class="col-sm-8">
                            <h5 class="mt-0 articleListHeading"><b><?php echo $article->title; ?></b></h5>
                            <p class="articleListPara"><?php echo str_limit($article->intro_text, 200); ?></p>
                            <a href="<?php echo $article->urldest; ?>" class="stretched-link"></a>
                        </div>
                        <div class="col-sm-2">
                            <p class="articleListUpdatedAt text-right">
                                <a href="/user/<?php echo $article->author->id; ?>">
                                    <img src="<?php echo $article->author->profile_photo; ?>" height="20px" style="border-radius:50%;" alt="codingstrokes.com/user/<?php echo $article->author->name; ?>"> <?php echo $article->author->name; ?>

                                </a>
                                <br>
                                Updated at : <?php echo $article->updated_At_Days; ?><br>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
                <a href='<?php echo $article->urldest; ?>' ><h4></h4></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
        </div>
        <?php else: ?>
            <div class="text-center">
                No result found!<br>
                <a href="/">Let's try once again</a>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>