<?php $__env->startSection('title'); ?>
    Search | Codingstrokes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="center-screen">
        <div class="homeSearchText">
            <blockquote class="blockquote text-center text-success">
                <p><?php echo $dailyquote->blockquote; ?></p>
                <footer class="blockquote-footer"><cite title="The Greek Way"><?php echo $dailyquote->blockquote_cite; ?></cite></footer>
            </blockquote>
        </div>
        <br>
        <form class="form-inline row" action="/search">
            <div class="form-group">
                <select class="form-control mb-2 mr-sm-2" id="category" name="category">
                    <option>Articles</option>
                    <option>Error Codes</option>
                    <option>Tutorials</option>
                </select>
            </div>
            <input type="text" class="form-control mb-2 mr-sm-2" placeholder="Enter keyword" id="search_text" name="search_text">
            <button type="submit" class="btn btn-success mb-2">Search</button>
        </form>
        
        <a href="/home"> <i class="fa fa-dashboard" style="color:green"></i> Continue without search</a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>