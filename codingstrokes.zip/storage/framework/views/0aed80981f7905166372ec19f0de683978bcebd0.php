<?php $__env->startSection('title'); ?>
<?php echo $user->name; ?> 
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row ">
        <div class="col-sm-2 col-md-2 userProfilePhoto">
                <!-- <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                <?php endif; ?> -->
                <img src="<?php echo $user->profile_photo; ?>" alt="<?php echo $user->name; ?>">
        </div>
        <div class="col-sm-6 col-md-6 userProfile">
            <br>
            <strong><?php echo $user->name; ?></strong><br>
            <!-- Calculating age -->
            <strong><?php echo $years = floor(abs(strtotime($user->date_of_birth) - strtotime(now())) / (365*60*60*24));; ?></strong><br>
            <strong><?php if($user->gender == 0): ?>
                        <?php echo 'Male'; ?>

                    <?php elseif($user->gender == 1): ?>
                        <?php echo 'Female'; ?>

                    <?php else: ?>
                        <?php echo 'Other'; ?>

                    <?php endif; ?>
            </strong><br>
            <strong><?php echo $user->email; ?></strong><br>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>