<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Coding Strokes | Learn and enhance your skills to find the perfect job</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<nav class="navbar navbar-expand-md navbar-light mb-3">
    <div class="container-fluid">
        <a href="#" class="navbar-brand mr-3"><img src="CodingStrokes.png" height="40px"></a>
        <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
            
            <div class="navbar-nav ml-auto">
                <a href="#" class="nav-item nav-link">Donate Us <i class="fa fa-heart"></i> </a> &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" class="nav-item nav-link">About Us</a> &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" class="nav-item nav-link">Pricing</a> &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" class="nav-item nav-link">Register</a> &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="#" class="nav-item nav-link">Login</a> &nbsp;&nbsp;&nbsp;&nbsp;
            </div>
        </div>
    </div>    
</nav>
<div class="container">
    <div class="jumbotron bg-white">
        <div class="row">
            <div class="col-sm-5">
                <img src="500_page_image.png" style="height: 350px;">
            </div>
            <div class="col-sm-7">
                <h4>Oops!! Something went wrong from our side. Please try again after some time.(500)</h4>
                <br>
                <p>
                    A server displays a HTTP 500 error (or internal server error) when it cannot process a request, a request that should be correct in principle.<br>
                    Since each server can use its own texts and terminology, the error message can take many forms.<br><br>
                    Here are some of the most common error messages:<br>
                    <ul>
                        <li>"Error 500 (Internal Server Error)"</li>
                        <li>"Error 500 - Internal server error"</li>
                        <li>"Internal server error"</li>
                        <li>"HTTP ERROR 500"</li>
                        <li>"Error 500"</li>
                    </ul>
                </p>
            </div>
        </div>
    </div>
</div>
</body>
</html>                            